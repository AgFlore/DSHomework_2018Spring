def gcd(a, b):
    if a % b == 0:
        return b
    else:
        return gcd(b, a % b)

while True:
    #读入两个整数a, b（以空格隔开），并转化成int，以下两种写法均可
    a, b = map(int, input("请输入两个整数：").split(' '))
    #[a, b] = [int(x) for x in input("请输入两个整数：").split(' ')]
    c = gcd(a, b)
	#python3除法(/)结果默认为float，需要转化为int或者用整除(//)
    d = int(a * b / c)
    print("最大公约数为：" + str(c))
    print("最小公倍数为：" + str(d))
