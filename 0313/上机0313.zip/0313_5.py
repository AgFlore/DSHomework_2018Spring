#思路是将每个人说的话用二维矩阵里的一行来表示，比如a说“不是我”，则代表有可能是b c d，表示成列表为[0, 1, 1, 1]
#判断谁说了谎只要看属于他的那一列是否为三真一假（即和为3）

true = [[0, 1, 1, 1],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
        [1, 1, 1, 0]]
sum_true = [0, 0, 0, 0]

for i in range(4):
    for j in range(4):
        sum_true[i] += true[j][i]
        if sum_true[i] == 3:
            print(str(i))
            break

#如果用numpy的话代码可以简洁一些，不过复杂度没有变化，代码如下：
#import numpy as np
#true = np.array([[0, 1, 1, 1], [0, 0, 1, 0], [0, 0, 0, 1], [1, 1, 1, 0]])
#print(int(np.argwhere(np.sum(true, axis=0)==3)))
