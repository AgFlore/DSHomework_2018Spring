#注意根据题目要求需要编写两层循环

import random

while True:
    a = random.randint(0, 99)
    #print(a)
    while True:
        b = input("请输入0到99之间的整数：")
        b = int(b)
        if b == 100:
            exit()
        if a == b:
            print("对了！")
            break
        elif a > b:
            print("小了...")
        else:
            print("大了...")

