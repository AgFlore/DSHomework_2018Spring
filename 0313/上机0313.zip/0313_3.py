dict = {}
dict['+'] = lambda a, b: a+b
dict['-'] = lambda a, b: a-b
dict['*'] = lambda a, b: a*b
dict['/'] = lambda a, b: a/b

while True:
    #输入两个整数a, b和符号c（输入时以空格隔开）
    a, b, c = input("请输入两个整数与符号:").split(' ')
    if b == '0' and c == '/':
        print("输入除数为0，请重新输入。")
        continue
    a = int(a)
    b = int(b)
    print(dict[c](a, b))
    
